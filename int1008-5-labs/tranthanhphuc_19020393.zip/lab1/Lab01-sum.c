#include<stdio.h>

int main(){
    int i,j;
    printf("Nhap vao so thu nhat: ");
    scanf("%d",&i);
    printf("Nhap vao so thu hai: ");
    scanf("%d",&j);
    printf("Tong cua %d va %d la %d",i,j,i+j);
    
    getchar();
    getchar();
    return 0;
}

